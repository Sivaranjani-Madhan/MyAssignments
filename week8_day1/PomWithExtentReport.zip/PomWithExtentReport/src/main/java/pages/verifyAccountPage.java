package pages;

import io.cucumber.java.en.Then;

public class verifyAccountPage {

	@Then("account should be created")
	public void verifyAccount()
	{
		System.out.println("account created successfully");
		
	}
}
