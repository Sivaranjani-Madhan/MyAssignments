package pages;

import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.Then;

public class ViewLeadPage extends BaseClass {
	

	@Then("Lead should be Created")
	public void verifyLead() {
		System.out.println("Lead is Created");

	}

}
