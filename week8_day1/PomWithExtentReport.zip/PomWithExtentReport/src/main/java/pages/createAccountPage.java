package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class createAccountPage extends BaseClass{

	@And("Enter the account name as {string}")
	public createAccountPage enterAccountname(String name)
	{
		 getDriver().findElement(By.xpath("//input[@id='accountName']")).sendKeys(name);
		 return this;
	}
	@And("Enter the Phonenumber as {string}")
	public createAccountPage enterPhonenmber(String number)
	{
		getDriver().findElement(By.id("primaryPhoneNumber")).sendKeys(number);
		return this;
	}
	@When("click on the save button")
	public verifyAccountPage clickSave()
	{
		Actions act=new Actions(getDriver());
		WebElement scrollElement = getDriver().findElement(By.className("smallSubmit"));
		act.scrollToElement(scrollElement).perform();
		scrollElement.click();
		return new verifyAccountPage();
		
	}
}
