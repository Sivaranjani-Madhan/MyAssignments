package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class CreateAccountFunctionality extends BaseClass {

	@BeforeTest
	public void setValues() {
		filename="CreateAccount";
		testName="CreateAcount";
		testDescription="CreateAccount with multiple data";
		testAuthor="Sivaranjani";
		testCategory="Regression";

	}
	
	@Test(dataProvider = "fetch")
	public void runCreateAccount(String username, String password,String name,String number) throws IOException
	{
		 LoginPage lp=new LoginPage();
		    lp.enterUsername(username)
		    .enterPassword(password)
		    .clickLoginButton()
		    .clickCrmsfa()
		    .clickAccountLink()
		    .clickCreateAccount()
		    .enterAccountname(name)
		    .enterPhonenmber(number)
		    .clickSave()
		    .verifyAccount();
	}
}
