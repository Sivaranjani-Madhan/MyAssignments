package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import base.BaseClass;

public class CreateAccountPage extends BaseClass{

	public CreateAccountPage(ChromeDriver driver)
	{
		this.driver=driver;

	}
	public CreateAccountPage enterAccountName(String name)
	{
		driver.findElement(By.id("accountName")).sendKeys(name);
		return this;
	}
	
	public CreateAccountPage enterPhoneNumber(String number)
	{
		driver.findElement(By.id("primaryPhoneNumber")).sendKeys(number);
		return this;
	}
	public ViewAccountPage clickSaveButton()
	{
		Actions act=new Actions(driver);
		WebElement scrollElement = driver.findElement(By.className("smallSubmit"));
		act.scrollToElement(scrollElement).perform();
		scrollElement.click();
		return new ViewAccountPage(driver);
	}
}
