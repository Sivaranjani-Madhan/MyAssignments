package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class LogoutPage extends BaseClass{

	public LogoutPage(ChromeDriver driver)
	{
		this.driver=driver;

	}
	public LogoutPage logOut()
	{
		driver.findElement(By.linkText("Logout")).click();
		return new LogoutPage(driver);
	}
}
