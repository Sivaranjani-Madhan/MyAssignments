package testcase;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class LogoutFuntionality extends BaseClass{

	@Test
	public void runLogout()
	{
		LoginPage lp=new LoginPage(driver);
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCrmsfa()
		.clickAccountLink()
		.clickCreateAccount()
		.clickSaveButton()
		.verifyAccount()
		.logOut();
		
	}
}
