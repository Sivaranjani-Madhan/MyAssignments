package testcase;

//Home Assignment 1: Convert TestScript to Page Object Model
//Home Assignment <3>: POM With Excel Integration
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class CreateAccountFunctionality extends BaseClass{

	@BeforeTest
	public void setValues()
	{
		filename="CreateAccount";
	}
	
	@Test(dataProvider="fetch")
	public void runCreateAccount(String name, String number)
	{
		LoginPage lp=new LoginPage();
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickCrmsfa()
		.clickAccountLink()
		.clickCreateAccount()
		.enterAccountName(name)
		.enterPhoneNumber(number)
		.clickSaveButton()
		.verifyAccount();
	}
}
