package pages;

import base.BaseClass;

public class ViewAccountPage extends BaseClass{

	public void verifyAccount() {
		System.out.println("Account is Created");

	}
}
