package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import utils.ReadExcel;

public class BaseClass {

	public static ChromeDriver driver;
	public String filename;
	
	@BeforeMethod
	public void preCondition()
	{
		ChromeOptions options=new ChromeOptions();
		options.addArguments("guest");
		driver=new ChromeDriver(options);
		driver.get("http://leaftaps.com/opentaps");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.manage().window().maximize();
	}
	
	@AfterMethod
	public void postCondition()
	{
		driver.close();
	}
	
	@DataProvider(name="fetch")
	public String[][] setDatas() throws IOException {

		String[][] readData = ReadExcel.readData(filename);  
		return readData;
	}
}
