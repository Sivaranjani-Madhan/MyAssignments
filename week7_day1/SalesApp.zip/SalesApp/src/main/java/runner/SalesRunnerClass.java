package runner;

//Home Assignment <4>: Pass Data from ScenarioOutline&Examples

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="src/main/java/features",glue= {"steps"},monochrome=true,publish=true)
public class SalesRunnerClass extends AbstractTestNGCucumberTests {

}
