package leaftapssteps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class EditAccountStepDefiniton extends LeafTapsBaseClass {

	@And("click on the Find Accounts link")
	public void click_on_the_find_accounts_link() {
		driver.findElement(By.linkText("Find Accounts")).click();

	}
	@And("click on the Phone tab")
	public void click_on_the_phone_tab() {
		driver.findElement(By.xpath("//span[text()='Phone']")).click();

	}

	@And("Enter the Number as {string}")
	public void enter_the_number_as(String number) {
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys(number);
	}
	@And("Click on the Find Accounts button")
	public void click_on_the_find_accounts_button() {
		driver.findElement(By.xpath("//button[text()='Find Accounts']")).click();

	}
	@And("click on the Account Name link {string}")
	public void click_on_the_account_name_link(String name) {
		driver.findElement(By.linkText(name)).click();

	}
	@And("click on the Edit button")
	public void click_on_the_edit_button() {
		driver.findElement(By.linkText("Edit")).click();

	}
	@And("select Ownership as Corporation")
	public void select_ownership_as_corporation() {
		WebElement dropDown = driver.findElement(By.name("ownershipEnumId"));
		Select options=new Select(dropDown);
		options.selectByVisibleText("Corporation");
	}
	@When("click on the save button")
	public void click_on_the_save_button() {
		driver.findElement(By.xpath("//input[@class='smallSubmit']")).click();
	}
	@Then("account should be Edited")
	public void account_should_be_edited() {
		String title = driver.getTitle();
		if(title.contains("Account Details"))
			System.out.println("acoount is edited successfully");
	}

}
