package leaftapssteps;

import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class LeafTapsBaseClass {
	
	public static ChromeDriver driver;

}
