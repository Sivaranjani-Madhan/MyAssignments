package leaftapssteps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateAccountStepDefinition extends LeafTapsBaseClass{

	@Given("Enter the username as {string}")
	public void enter_the_username_as(String username) {
		driver.findElement(By.id("username")).sendKeys(username);

	}
	@Given("Enter the password as {string}")
	public void enter_the_password_as(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}
	@When("Click on the Login button")
	public void click_on_the_login_button() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}
	@And("Click on the crmsfa link")
	public void click_on_the_crmsfa_link() {
		driver.findElement(By.linkText("CRM/SFA")).click();
	}
	@And("click on the Accounts link")
	public void click_on_the_accounts_link() {
		driver.findElement(By.linkText("Accounts")).click();

	}
	@And("click on the Create Account link")
	public void click_on_the_create_account_link() {
		driver.findElement(By.linkText("Create Account")).click();

	}
	@And("Enter the Account Name as {string}")
	public void enter_the_account_name_as_tester(String name) {
		driver.findElement(By.xpath("//input[@id='accountName']")).sendKeys(name);

	}
	@And("select Ownership as Public Corporation")
	public void select_ownership_as_public_corporation() throws InterruptedException {
		WebElement dropDown = driver.findElement(By.name("ownershipEnumId"));
		Select options=new Select(dropDown);
		options.selectByVisibleText("Public Corporation");
		Thread.sleep(1000);
	}
	@And("Enter the Phone Number as {string}")
	public void enter_the_phone_number_as(String number) {
		driver.findElement(By.id("primaryPhoneNumber")).sendKeys(number);
	}

	@And("Click on the create Account button")
	public void click_on_the_create_Account_button() throws InterruptedException
	{
		Actions act=new Actions(driver);
		WebElement scrollElement = driver.findElement(By.className("smallSubmit"));
		Thread.sleep(1000);
		act.scrollToElement(scrollElement).perform();
		scrollElement.click();
		
	}

	@Then("account should be created")
	public void account_should_be_created() {
		
		String title = driver.getTitle();
		if(title.contains("Account Details"))
		System.out.println("acoount is created successfully");
	}


}
