package leaftapssteps;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DeleteAccountStepDefinition extends LeafTapsBaseClass{

	@And("click on the Deactivate Account button")
	public void click_on_the_deactivate_account_button() throws InterruptedException {
	    driver.findElement(By.linkText("Deactivate Account")).click();
	    Thread.sleep(1000);
	}
	@When("click on the ok button")
	public void click_on_the_ok_button() {
		Alert alret = driver.switchTo().alert();
		alret.accept();
	}
	@Then("account should be deleted")
	public void account_should_be_deleted() {
		System.out.println("deleted successfully");
	}

}
