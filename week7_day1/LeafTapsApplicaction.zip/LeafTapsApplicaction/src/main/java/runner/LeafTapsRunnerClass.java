package runner;
//Classroom Assignment <4>: Hooks Implementation
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="src/main/java/leaftapsfeatures",glue= {"leaftapssteps","leaftapshooks"},monochrome=true,publish=true)
public class LeafTapsRunnerClass extends AbstractTestNGCucumberTests{

}
